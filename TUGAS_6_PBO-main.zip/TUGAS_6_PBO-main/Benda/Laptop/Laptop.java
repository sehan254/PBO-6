package Benda.Laptop;
public interface Laptop {

    int MAX_VOL = 100;
    int MIN_VOL = 0;

    
    void powerOn();
    void powerOff();
    void volumeUp();
    void volumeDown();
}
